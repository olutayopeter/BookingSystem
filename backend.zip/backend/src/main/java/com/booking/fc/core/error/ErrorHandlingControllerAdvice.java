package com.booking.fc.core.error;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.booking.fc.common.dto.ValidationErrorResponseDto;

import javax.validation.ConstraintViolationException;

@ControllerAdvice
public class ErrorHandlingControllerAdvice {
  @ExceptionHandler(ConstraintViolationException.class)
  ResponseEntity<ValidationErrorResponseDto> onConstraintValidation(
      ConstraintViolationException e) {
    return ResponseEntity.badRequest()
        .body(ValidationErrorResponseDto.from(e.getConstraintViolations()));
  }

  @ExceptionHandler(MethodArgumentNotValidException.class)
  ResponseEntity<ValidationErrorResponseDto> onMethodArgumentNotValid(
      MethodArgumentNotValidException e) {
    return ResponseEntity.badRequest()
        .body(ValidationErrorResponseDto.from(e.getBindingResult().getFieldErrors()));
  }
}
