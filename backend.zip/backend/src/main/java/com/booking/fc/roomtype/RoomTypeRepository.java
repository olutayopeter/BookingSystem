package com.booking.fc.roomtype;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface RoomTypeRepository extends JpaRepository<RoomType, Long> {
  Page<RoomType> findAllByOwnerId(Pageable pageable, Long ownerId);
}
