package com.booking.fc.user;

import org.mapstruct.Mapper;

import com.booking.fc.user.dto.response.UserResponseDto;

@Mapper(componentModel = "spring")
public interface UserMapper {

  UserResponseDto toResponse(User user);
}
