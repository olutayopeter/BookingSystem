package com.booking.fc.bookingregistration.exception;

public class BookingRegistrationRoomTypeNotFound extends RuntimeException{

    public BookingRegistrationRoomTypeNotFound() {
        super("Investment basket not found");
    }
}
