package com.booking.fc.roomtype;

import com.booking.fc.roomtype.dto.request.UpdateRoomTypeRequestDto;
import com.booking.fc.roomtype.exception.RoomTypeNotFoundException;
import com.booking.fc.roomtype.exception.RoomTypeNotOwnedException;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class RoomTypeService {
	private final RoomTypeRepository roomTypeRepository;
	private final RoomTypeMapper roomTypeMapper;

	public Page<RoomType> findAllRoomTypes(Pageable page, Long customerUserId) {
		return roomTypeRepository.findAllByOwnerId(page, customerUserId);
	}

	public RoomType updateRoomType(Long roomTypeId, UpdateRoomTypeRequestDto updateRoomTypeRequest, Long customerUserId) {
		RoomType roomType = roomTypeRepository.findById(roomTypeId).orElseThrow(RoomTypeNotFoundException::new);

		if (!roomType.getOwner().getId().equals(customerUserId)) {
			throw new RoomTypeNotOwnedException();
		}

		roomTypeMapper.updateEntity(roomType, updateRoomTypeRequest);
		return roomTypeRepository.save(roomType);
	}

	public RoomType saveRoomType(RoomType roomType) {
		return roomTypeRepository.save(roomType);
	}

	public void deleteRoomType(Long roomTypeId, Long customerUserId) {
		RoomType roomType = roomTypeRepository.findById(roomTypeId).orElseThrow(RoomTypeNotFoundException::new);

		if (!roomType.getOwner().getId().equals(customerUserId)) {
			throw new RoomTypeNotOwnedException();
		}

		roomTypeRepository.delete(roomType);
	}
}
