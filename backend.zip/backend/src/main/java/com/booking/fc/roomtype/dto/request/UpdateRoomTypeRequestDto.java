package com.booking.fc.roomtype.dto.request;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;



@Data
public class UpdateRoomTypeRequestDto {

	  
	  @NotNull
	  @Size(min = 3, max = 100)
	  private String roomType;

	  @ApiModelProperty(required = true)
	  private double weekDaysRate;
	  
	  @ApiModelProperty(required = true)
	  @NotBlank private double weekendRate;
	  
	  
	}