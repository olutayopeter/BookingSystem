package com.booking.fc.roomtype.dto.response;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.time.Instant;

@Data
public class RoomTypeResponseDto {

  @ApiModelProperty(required = true)
  private Long id;

  @ApiModelProperty(required = true)
  private double weekDaysRate;

  @ApiModelProperty(required = true)
  private double weekendRate;

  @ApiModelProperty(required = true)
  private Instant createdDate;
}
