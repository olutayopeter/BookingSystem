package com.booking.fc.bookingregistration;


import org.mapstruct.InjectionStrategy;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;

import com.booking.fc.bookingregistration.dto.request.SaveBookingRegistrationRequestDto;
import com.booking.fc.bookingregistration.dto.request.UpdateBookingRegistrationRequestDto;
import com.booking.fc.bookingregistration.dto.response.BookingRegistrationResponseDto;
import com.booking.fc.roomtype.RoomType;
import com.booking.fc.roomtype.dto.request.SaveRoomTypeRequestDto;
import com.booking.fc.roomtype.dto.request.UpdateRoomTypeRequestDto;
import com.booking.fc.roomtype.dto.response.RoomTypeResponseDto;



@Mapper(componentModel = "spring", injectionStrategy = InjectionStrategy.CONSTRUCTOR)
public interface BookingRegistrationMapper {

	BookingRegistrationResponseDto toResponse(BookingRegistration bookingRegistration);

	  @Mapping(target = "owner", ignore = true)
	  @Mapping(target = "id", ignore = true)
	  @Mapping(target = "expectedCheckInTime", ignore = true)
	  @Mapping(target = "expectedCheckOutTime", ignore = true)
	  @Mapping(target = "roomType", ignore = true)
	  BookingRegistration toEntity(SaveBookingRegistrationRequestDto requestDto);

	  @Mapping(target = "owner", ignore = true)
	  @Mapping(target = "id", ignore = true)
	  @Mapping(target = "expectedCheckInTime", ignore = true)
	  @Mapping(target = "expectedCheckOutTime", ignore = true)
	  @Mapping(target = "roomType", ignore = true)
	  void updateEntity(@MappingTarget BookingRegistration entity, UpdateBookingRegistrationRequestDto updateBookingRegistrationType);
}

