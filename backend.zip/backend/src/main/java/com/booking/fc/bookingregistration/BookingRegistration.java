package com.booking.fc.bookingregistration;


import lombok.Data;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import com.booking.fc.roomtype.RoomType;
import com.booking.fc.user.User;

import java.math.BigInteger;

import javax.persistence.*;


@Data
@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name = "booking_registration")
public class BookingRegistration {
  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  @Column(name = "id", nullable = false)
  private long id;
  
  @ManyToOne(fetch = FetchType.LAZY, optional = false)
  @JoinColumn(name = "roomtype_id", nullable = false)
  @OnDelete(action = OnDeleteAction.CASCADE)
  private RoomType roomType;

  @Column(name = "reservation_id", nullable = false)
  private long reservationId;
  
  @Column(name = "customer_id", nullable = false)
  private int customerId;
  
  @Column(name = "hourly_rate", nullable = false)
  private BigInteger hourlyRate;
  
  @Column(name = "status", nullable = false)
  private String status;
  
  @Column(name = "expected_checkin_time")
  @Temporal(TemporalType.TIMESTAMP)
  private java.util.Date expectedCheckInTime;
  
  @Column(name = "expected_checkout_time")
  @Temporal(TemporalType.TIMESTAMP)
  private java.util.Date expectedCheckOutTime;

  @ManyToOne(fetch = FetchType.LAZY, optional = false)
  @JoinColumn(name = "owner_id", nullable = false)
  @CreatedBy
  private User owner;
  
  
}
