package com.booking.fc.roomtype.exception;

public class RoomTypeNotFoundException extends RuntimeException {
  public RoomTypeNotFoundException() {
    super("Basket not found");
  }
}
