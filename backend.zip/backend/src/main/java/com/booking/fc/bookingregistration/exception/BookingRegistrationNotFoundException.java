package com.booking.fc.bookingregistration.exception;

public class BookingRegistrationNotFoundException extends RuntimeException {
  public BookingRegistrationNotFoundException() {
    super("Basket not found");
  }
}
