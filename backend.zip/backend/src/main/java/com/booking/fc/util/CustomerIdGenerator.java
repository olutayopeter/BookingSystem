package com.booking.fc.util;

import java.util.Random;

public class CustomerIdGenerator {
	
	public static String generate() {
		
		
		Random random = new Random();
		
		int x = random.nextInt(100000);
		
		String customerId = String.valueOf(x);
		
		return customerId;
	}

}
