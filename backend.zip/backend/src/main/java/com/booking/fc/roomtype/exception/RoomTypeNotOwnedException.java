package com.booking.fc.roomtype.exception;

public class RoomTypeNotOwnedException extends RuntimeException {
  public RoomTypeNotOwnedException() {
    super("User does not own the basket");
  }
}
