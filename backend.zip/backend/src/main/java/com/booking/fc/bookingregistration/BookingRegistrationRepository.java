package com.booking.fc.bookingregistration;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BookingRegistrationRepository extends JpaRepository<BookingRegistration, Long> {
	
	Page<BookingRegistration> findByRoomTypeIdAndOwnerId(Long roomTypeId, Long ownerId, Pageable pageable);

	Optional<BookingRegistration> findByRoomTypeIdAndId(Long roomTypeId, Long registrationId);
  
  
}


