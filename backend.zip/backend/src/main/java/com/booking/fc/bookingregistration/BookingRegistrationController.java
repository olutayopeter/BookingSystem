package com.booking.fc.bookingregistration;


import io.swagger.annotations.*;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.booking.fc.bookingregistration.dto.request.SaveBookingRegistrationRequestDto;
import com.booking.fc.bookingregistration.dto.request.UpdateBookingRegistrationRequestDto;
import com.booking.fc.bookingregistration.dto.response.BookingRegistrationResponseDto;
import com.booking.fc.bookingregistration.exception.BookingRegistrationNotFoundException;
import com.booking.fc.bookingregistration.exception.BookingRegistrationNotOwnedException;
import com.booking.fc.bookingregistration.exception.BookingRegistrationRoomTypeNotFound;
import com.booking.fc.common.annotations.CurrentAppUser;
import com.booking.fc.common.dto.ApiErrorResponseDto;
import com.booking.fc.common.dto.ValidationErrorResponseDto;
import com.booking.fc.core.security.AppUser;
import javax.validation.Valid;
import java.net.URI;

@Api(tags = "BookingRegistration")
@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class BookingRegistrationController {

	private final BookingRegistrationService bookingRegistrationService;
	private final BookingRegistrationMapper mapper;
	  
	
	/*
	 * @ApiOperation( value =
	 * "Get booking registrations that belong to current user", authorizations =
	 * {@Authorization(value = "Authorization")})
	 * 
	 * @ApiResponses( value = {
	 * 
	 * @ApiResponse(code = 200, message = "Successful response"),
	 * 
	 * @ApiResponse(code = 403, message = "Unauthorized"), })
	 * 
	 * @GetMapping( path = "/me/roomTypes/{roomTypeId}/bookingRegistrations",
	 * produces = MediaType.APPLICATION_JSON_VALUE) public static
	 * ResponseEntity<Page<BookingRegistrationResponseDto>>
	 * getBookingRegistrationsByRoomTypeId(
	 * 
	 * @PathVariable Long roomTypeId, Pageable pageable, @CurrentAppUser AppUser
	 * appUser) { Page<BookingRegistration> bookingRegistrations = //
	 * BookingRegistrationService.findByRoomTypeId(roomTypeId, appUser.getId(),
	 * pageable);
	 * 
	 * return
	 * ResponseEntity.ok().body(bookingRegistrations.map(mapper::toResponse)); }
	 */
	 

	  @ApiOperation(
	      value = "Get booking registration details",
	      authorizations = {@Authorization(value = "Authorization")})
	  @ApiResponses(
	      value = {
	        @ApiResponse(code = 200, message = "Successful response"),
	        @ApiResponse(code = 403, message = "Unauthorized"),
	        @ApiResponse(
	            code = 404,
	            message = "Investment not found",
	            response = ApiErrorResponseDto.class)
	      })
	  @GetMapping(
	      path = "/me/roomTypes/{roomTypeId}/bookingRegistrations/{bookingRegistrationId}",
	      produces = MediaType.APPLICATION_JSON_VALUE)
	  public ResponseEntity<BookingRegistrationResponseDto> getBookingRegistrationDetails(
	      @PathVariable Long roomTypeId,
	      @PathVariable Long bookingRegistrationId,
	      @CurrentAppUser AppUser appUser) {
	      BookingRegistration foundBookingRegistration =
	       bookingRegistrationService.getByRoomTypeIdAndId(roomTypeId, bookingRegistrationId, appUser.getId());

	    return ResponseEntity.ok(mapper.toResponse(foundBookingRegistration));
	  }

	  @ApiOperation(
	      value = "Save a booking registration",
	      authorizations = {@Authorization(value = "Authorization")})
	  @ApiResponses(
	      value = {
	        @ApiResponse(code = 201, message = "Created"),
	        @ApiResponse(
	            code = 400,
	            message = "Invalid request body",
	            response = ValidationErrorResponseDto.class),
	        @ApiResponse(code = 403, message = "Unauthorized"),
	        @ApiResponse(code = 404, message = "Room type not found", response = ApiErrorResponseDto.class)
	      })
	  @PostMapping(
	      path = "/me/roomTypes/{roomTypeId}/bookingRegistrations",
	      produces = MediaType.APPLICATION_JSON_VALUE,
	      consumes = MediaType.APPLICATION_JSON_VALUE)
	  public ResponseEntity<BookingRegistrationResponseDto> saveBookingRegistration(
	      @PathVariable Long roomTypeId, @Valid @RequestBody SaveBookingRegistrationRequestDto reg) {
	    BookingRegistration savedBookingRegistration =
	        bookingRegistrationService.saveBookingRegistration(mapper.toEntity(reg), roomTypeId);

	    URI location =
	        URI.create("/me/roomTypes/" + roomTypeId + "/investments/" + savedBookingRegistration.getId());
	    
	    return ResponseEntity.created(location).body(mapper.toResponse(savedBookingRegistration));

	    
	  }

	  @ApiOperation(
	      value = "Update a booking registration",
	      authorizations = {@Authorization(value = "Authorization")})
	  @ApiResponses(
	      value = {
	        @ApiResponse(code = 200, message = "Success"),
	        @ApiResponse(
	            code = 400,
	            message = "Invalid request body",
	            response = ValidationErrorResponseDto.class),
	        @ApiResponse(code = 403, message = "Unauthorized"),
	        @ApiResponse(
	            code = 404,
	            message = "Investment not found",
	            response = ApiErrorResponseDto.class)
	      })
	  @PutMapping(
	      path = "/me/roomTypes/{roomTypeId}/bookingRegistrations/{bookingRegistrationId}",
	      produces = MediaType.APPLICATION_JSON_VALUE,
	      consumes = MediaType.APPLICATION_JSON_VALUE)
	  public ResponseEntity<BookingRegistrationResponseDto> updateBookingRegistration(
	      @PathVariable Long bookingRegistrationId,
	      @PathVariable Long roomTypeId,
	      @Valid @RequestBody UpdateBookingRegistrationRequestDto updateBookingRegistrationRequestDto,
	      @CurrentAppUser AppUser appUser) {
	      BookingRegistration updatedBookingRegistration =
	        bookingRegistrationService.updateBookingRegistrationByRoomTypeIdAndId(
	            roomTypeId, bookingRegistrationId, updateBookingRegistrationRequestDto, appUser.getId());

	    return ResponseEntity.ok().body(mapper.toResponse(updatedBookingRegistration));
	  }

	  @ApiOperation(
	      value = "Delete a booking registration",
	      authorizations = {@Authorization(value = "Authorization")})
	  @ApiResponses(
	      value = {
	        @ApiResponse(code = 200, message = "Success"),
	        @ApiResponse(code = 403, message = "Unauthorized"),
	        @ApiResponse(
	            code = 404,
	            message = "Booking registration not found",
	            response = ApiErrorResponseDto.class)
	      })
	  @DeleteMapping(
	      path = "/me/roomTypes/{roomTypeId}/bookingRegistrations/{bookingRegistrationId}",
	      produces = MediaType.APPLICATION_JSON_VALUE)
	  public ResponseEntity<Void> deleteInvestment(
	      @PathVariable Long roomTypeId,
	      @PathVariable Long bookingRegistrationId,
	      @CurrentAppUser AppUser appUser) {
	      bookingRegistrationService.deleteByRoomTypeIdAndId(roomTypeId, bookingRegistrationId, appUser.getId());

	    return ResponseEntity.ok().build();
	  }

	  @ExceptionHandler(BookingRegistrationNotFoundException.class)
	  public ResponseEntity<ApiErrorResponseDto> handleNotFound(BookingRegistrationNotFoundException exception) {
	    return new ResponseEntity<>(
	        ApiErrorResponseDto.of(exception.getMessage()), HttpStatus.NOT_FOUND);
	  }

	  @ExceptionHandler(BookingRegistrationRoomTypeNotFound.class)
	  public ResponseEntity<ApiErrorResponseDto> handleNotFound(BookingRegistrationRoomTypeNotFound exception) {
	    return new ResponseEntity<>(
	        ApiErrorResponseDto.of(exception.getMessage()), HttpStatus.NOT_FOUND);
	  }

	  @ExceptionHandler(BookingRegistrationNotOwnedException.class)
	  public ResponseEntity<ApiErrorResponseDto> handleNotFound(BookingRegistrationNotOwnedException exception) {
	    return new ResponseEntity<>(
	        ApiErrorResponseDto.of(exception.getMessage()), HttpStatus.FORBIDDEN);
	  }
	}
