package com.booking.fc.bookingregistration.dto.request;

import lombok.Data;

import java.math.BigDecimal;
import java.math.BigInteger;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnore;



@Data
public class SaveBookingRegistrationRequestDto {

	  @Min(1)
	  @NotNull
	  private Long reservationId;

	  @Min(1)
	  @NotNull
	  private Integer customerId;

	  @Min(1)
	  @NotNull
	  private BigInteger hourlyRate;
	  
	  @JsonIgnore
	  private String status = "PENDING";

	  
	  @NotNull
	  private java.util.Date expectedCheckInTime;

	  @NotNull
	  private java.util.Date expectedCheckOutTime;

	   
	

}

