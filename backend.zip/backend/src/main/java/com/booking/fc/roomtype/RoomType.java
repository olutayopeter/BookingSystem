package com.booking.fc.roomtype;

import lombok.Data;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.booking.fc.user.User;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.Instant;

@Data
@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name = "room_type")
public class RoomType {
  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  @Column(name = "room_id", nullable = false)
  private long id;

  @Column(name = "room_type_name", nullable = false)
  private String roomType;

  @Column(name = "week_days_rate_increase", nullable = false)
  private double weekDaysRate;
  
  @Column(name = "weekend_rate_increase", nullable = false)
  private double weekendRate;
  
  @Column(name = "created_date", nullable = false)
  @CreatedDate
  private Instant createdDate;

  @ManyToOne(fetch = FetchType.LAZY, optional = false)
  @JoinColumn(name = "owner_id", nullable = false)
  @CreatedBy
  private User owner;
}
