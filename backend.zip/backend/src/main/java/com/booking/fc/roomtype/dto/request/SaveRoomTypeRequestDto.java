package com.booking.fc.roomtype.dto.request;

import lombok.Data;

import java.math.BigDecimal;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;



@Data
public class SaveRoomTypeRequestDto {

	@NotNull
	@Size(min = 3, max = 100)
	private String roomType;

	@NotBlank
	private double weekDaysRate;

	@NotBlank
	private double weekendRate;

	

}

