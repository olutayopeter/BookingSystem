package com.booking.fc.roomtype;

import com.booking.fc.roomtype.dto.request.SaveRoomTypeRequestDto;
import com.booking.fc.roomtype.dto.request.UpdateRoomTypeRequestDto;
import com.booking.fc.roomtype.dto.response.RoomTypeResponseDto;
import org.mapstruct.InjectionStrategy;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;

@Mapper(componentModel = "spring", injectionStrategy = InjectionStrategy.CONSTRUCTOR)
public interface RoomTypeMapper {

  RoomTypeResponseDto toResponse(RoomType roomType);

  @Mapping(target = "owner", ignore = true)
  @Mapping(target = "id", ignore = true)
  @Mapping(target = "createdDate", ignore = true)
  RoomType toEntity(SaveRoomTypeRequestDto requestDto);

  @Mapping(target = "owner", ignore = true)
  @Mapping(target = "id", ignore = true)
  @Mapping(target = "createdDate", ignore = true)
  void updateEntity(@MappingTarget RoomType entity, UpdateRoomTypeRequestDto updateRoomType);
}

