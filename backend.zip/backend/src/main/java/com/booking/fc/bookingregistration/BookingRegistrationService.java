package com.booking.fc.bookingregistration;


import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import com.booking.fc.bookingregistration.dto.request.UpdateBookingRegistrationRequestDto;
import com.booking.fc.bookingregistration.exception.BookingRegistrationNotFoundException;
import com.booking.fc.bookingregistration.exception.BookingRegistrationNotOwnedException;
import com.booking.fc.bookingregistration.exception.BookingRegistrationRoomTypeNotFound;
import com.booking.fc.roomtype.RoomType;
import com.booking.fc.roomtype.RoomTypeRepository;




@Service
@RequiredArgsConstructor
public class BookingRegistrationService {
	
	  private  BookingRegistrationRepository bookingRegistrationRepository;
	  private  BookingRegistrationMapper bookingRegistrationMapper;
	  private  RoomTypeRepository roomTypeRepository;

	  public  Page<BookingRegistration> findByRoomTypeId(Long roomTypeId, Long userId, Pageable pageable) {
	    return bookingRegistrationRepository.findByRoomTypeIdAndOwnerId(roomTypeId, userId, pageable);
	  }

	  public BookingRegistration getByRoomTypeIdAndId(Long roomTypeId, Long bookingRegistrationId, Long userId) {
	    BookingRegistration bookingRegistration = bookingRegistrationRepository
	            .findByRoomTypeIdAndId(roomTypeId, bookingRegistrationId)
	            .orElseThrow(BookingRegistrationNotFoundException::new);

	    if (!bookingRegistration.getOwner().getId().equals(userId)) {
	      throw new BookingRegistrationNotOwnedException();
	    }

	    return bookingRegistration;
	  }

	  public BookingRegistration saveBookingRegistration(BookingRegistration bookingRegistration, Long roomTypeId) {
	    RoomType roomType = roomTypeRepository.findById(roomTypeId).orElseThrow(BookingRegistrationRoomTypeNotFound::new);

	    bookingRegistration.setRoomType(roomType);
	    return bookingRegistrationRepository.save(bookingRegistration);
	  }

	  public BookingRegistration updateBookingRegistrationByRoomTypeIdAndId(
	      Long roomTypeId, Long bookingRegistrationId, UpdateBookingRegistrationRequestDto bookingRegistrationRequest, Long userId) {
	    BookingRegistration bookingRegistration =
	        bookingRegistrationRepository
	            .findByRoomTypeIdAndId(roomTypeId, bookingRegistrationId)
	            .orElseThrow(BookingRegistrationNotFoundException::new);

	    if (!bookingRegistration.getOwner().getId().equals(userId)) {
	      throw new BookingRegistrationNotOwnedException();
	    }

	    bookingRegistrationMapper.updateEntity(bookingRegistration,bookingRegistrationRequest);
	    return bookingRegistrationRepository.save(bookingRegistration);
	  }

	  public void deleteByRoomTypeIdAndId(Long roomTypeId, Long bookingRegistrationId, Long userId) {
	    BookingRegistration bookingRegistration =
	        bookingRegistrationRepository
	            .findByRoomTypeIdAndId(roomTypeId, bookingRegistrationId)
	            .orElseThrow(BookingRegistrationNotFoundException::new);

	    if (!bookingRegistration.getOwner().getId().equals(userId)) {
	      throw new BookingRegistrationNotOwnedException();
	    }

	    bookingRegistrationRepository.delete(bookingRegistration);
	  }
	  
}