package com.booking.fc.bookingregistration.dto.response;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigInteger;
import java.time.Instant;

@Data
public class BookingRegistrationResponseDto {

	@ApiModelProperty(required = true)
	  private long id;

	  @ApiModelProperty(required = true)
	  private long reservationId;

	  @ApiModelProperty(required = true)
	  private int customerId;

	  @ApiModelProperty(required = true)
	  private BigInteger hourlyRate;

	  @ApiModelProperty(required = true)
	  private java.util.Date expectedCheckInTime;

	  @ApiModelProperty(required = true)
	  private java.util.Date expectedCheckOutTime;

	  
	  
}
