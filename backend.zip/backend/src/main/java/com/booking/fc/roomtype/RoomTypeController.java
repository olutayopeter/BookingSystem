package com.booking.fc.roomtype;

import com.booking.fc.common.annotations.CurrentAppUser;
import com.booking.fc.common.dto.ApiErrorResponseDto;
import com.booking.fc.common.dto.ValidationErrorResponseDto;
import com.booking.fc.core.security.AppUser;
import com.booking.fc.roomtype.dto.request.SaveRoomTypeRequestDto;
import com.booking.fc.roomtype.dto.request.UpdateRoomTypeRequestDto;
import com.booking.fc.roomtype.dto.response.RoomTypeResponseDto;
import com.booking.fc.roomtype.exception.RoomTypeNotFoundException;
import com.booking.fc.roomtype.exception.RoomTypeNotOwnedException;
import io.swagger.annotations.*;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.net.URI;

@Api(tags = "RoomType")
@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class RoomTypeController {

  private final RoomTypeService  roomTypeService;
  private final RoomTypeMapper  roomTypeMapper;

  @ApiOperation(
      value = "Get room types that belong to current customer",
      authorizations = {@Authorization(value = "Authorization")})
  @ApiResponses(
      value = {
        @ApiResponse(code = 200, message = "Success"),
        @ApiResponse(code = 403, message = "Unauthorized"),
      })
  @GetMapping(path = "/me/roomTypes", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<Page<RoomTypeResponseDto>> getRoomTypes(
      Pageable pageable, @CurrentAppUser AppUser appUser) {

    Page<RoomType> roomTypesPage = roomTypeService.findAllRoomTypes(pageable, appUser.getId());

    return ResponseEntity.ok(roomTypesPage.map(roomTypeMapper::toResponse));
  }

  @ApiOperation(
      value = "Save a Room type",
      authorizations = {@Authorization(value = "Authorization")})
  @ApiResponses(
      value = {
        @ApiResponse(code = 201, message = "Created"),
        @ApiResponse(
            code = 400,
            message = "Invalid request body",
            response = ValidationErrorResponseDto.class),
        @ApiResponse(code = 403, message = "Unauthorized"),
      })
  @PostMapping(
      path = "/me/roomTypes",
      produces = MediaType.APPLICATION_JSON_VALUE,
      consumes = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<RoomTypeResponseDto> saveRoomType(
      @Valid @RequestBody SaveRoomTypeRequestDto roomType) {

    RoomType savedRoomType = roomTypeService.saveRoomType(roomTypeMapper.toEntity(roomType));
    URI location = URI.create("/me/roomTypes/" +savedRoomType.getId());

    return ResponseEntity.created(location).body(roomTypeMapper.toResponse(savedRoomType));
  }

  @ApiOperation(
      value = "Update a room type",
      authorizations = {@Authorization(value = "Authorization")})
  @ApiResponses(
      value = {
        @ApiResponse(code = 200, message = "Success"),
        @ApiResponse(
            code = 400,
            message = "Invalid request body",
            response = ValidationErrorResponseDto.class),
        @ApiResponse(code = 403, message = "Unauthorized"),
        @ApiResponse(code = 404, message = "Room type not found", response = ApiErrorResponseDto.class)
      })
  @PutMapping(
      path = "/me/roomTypes/{roomTypeId}",
      produces = MediaType.APPLICATION_JSON_VALUE,
      consumes = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<RoomTypeResponseDto> updateRoomType(
      @PathVariable Long roomTypeId,
      @Valid @RequestBody UpdateRoomTypeRequestDto updateRoomTypeRequestDto,
      @CurrentAppUser AppUser appUser) {

     RoomType updatedRoomType = roomTypeService.updateRoomType(roomTypeId, updateRoomTypeRequestDto, appUser.getId());

    return ResponseEntity.ok(roomTypeMapper.toResponse(updatedRoomType));
  }

  @ApiOperation(
      value = "Delete a room type",
      authorizations = {@Authorization(value = "Authorization")})
  @ApiResponses(
      value = {
        @ApiResponse(code = 200, message = "Success"),
        @ApiResponse(code = 403, message = "Unauthorized"),
        @ApiResponse(code = 404, message = "Room type not found", response = ApiErrorResponseDto.class)
      })
  @DeleteMapping(path = "/me/roomTypes/{roomTypeId}", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<Void> deleteRoomType(
      @PathVariable Long roomTypeId, @CurrentAppUser AppUser appUser) {

    roomTypeService.deleteRoomType(roomTypeId, appUser.getId());

    return ResponseEntity.ok().build();
  }

  @ExceptionHandler(RoomTypeNotFoundException.class)
  public ResponseEntity<ApiErrorResponseDto> handleNotFound(RoomTypeNotFoundException exception) {
    return new ResponseEntity<>(
        ApiErrorResponseDto.of(exception.getMessage()), HttpStatus.NOT_FOUND);
  }

  @ExceptionHandler(RoomTypeNotOwnedException.class)
  public ResponseEntity<ApiErrorResponseDto> handleNotOwned(RoomTypeNotOwnedException exception) {
    return new ResponseEntity<>(
        ApiErrorResponseDto.of(exception.getMessage()), HttpStatus.FORBIDDEN);
  }
}
