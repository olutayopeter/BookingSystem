package com.booking.fc.bookingregistration.exception;

public class BookingRegistrationNotOwnedException extends RuntimeException {
  public BookingRegistrationNotOwnedException() {
    super("User does not own the basket");
  }
}
