package com.nalhin.fc

import com.nalhin.fc.test.annotations.IntegrationTest
import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest


@SpringBootTest
@IntegrationTest
class ApplicationTests {

  @Test
  void contextLoads() {
  }

}
